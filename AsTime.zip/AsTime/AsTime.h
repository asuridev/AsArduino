#ifndef AsTime_h
#define AsTime_h

#include "Arduino.h"

extern "C"
{
    typedef void (*varFunction)(void);
}

class AsTime
{
public:
    AsTime();
    void setTimeout(varFunction callback, long time);
    void run();
    void clear();
    unsigned long getTime();

private:
    unsigned long _timer;
    boolean _enable = false;
};

#endif