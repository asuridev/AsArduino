#include "Arduino.h"
#include "AsTime.h"

AsTime::AsTime()
{
}

void AsTime::setTimeout(varFunction callback, long time)
{
    if (_enable)
    {
        if (millis() - _timer > time)
        {
            _enable = false;
            callback();
        }
    }
}

void AsTime::run()
{
    if (!_enable)
    {
        _timer = millis();
        _enable = true;
    }
}

void AsTime::clear()
{
    _enable = false;
}

unsigned long AsTime::getTime()
{
    if (_enable)
    {
        return (millis() - _timer);
    }
    else
    {
        return 0;
    }
}