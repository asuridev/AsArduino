/*Antonio Jose Suarez rincon
antoniosuarezrincon@gmail.com
AsButton es una libreria escrita en arduino basada en callback,  permite trabajar
los eventos de los pines de los microcontroladores con nombres
de metodos similares a JS.
-requiere que los pines se activen a nivel bajo.
-los eventos admitidos son:
    keydown
    keyup
    keyhold
    click
*/
#ifndef AsButton_h
#define AsButton_h
#include "Arduino.h"

extern "C"
{
    typedef void (*varFunction)(void);
}

class AsButton
{
public:
    AsButton(byte pin);
    void addEventListener(String event, varFunction callback);

private:
    byte _pin;
    unsigned long _timer;
    boolean _enable = false;
    byte _count = 0;
    byte _rebote = 0;
};

#endif