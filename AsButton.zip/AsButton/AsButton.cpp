#include "Arduino.h"
#include "AsButton.h"

AsButton::AsButton(byte pin)
{
    pinMode(pin, INPUT_PULLUP);
    _pin = pin;
    _timer = millis();
}

void AsButton::addEventListener(String event, varFunction callback)
{
    if (millis() - _timer > 50)
    { // intervalo de 50 ms
        _timer = millis();
        if (!_enable)
        {
            _rebote++;
            if (_rebote >= 6)
            {
                _enable = true;
            }
        }
        else
        {
            if (digitalRead(_pin) == LOW)
            {
                _count++;
                if (_count == 1)
                {
                    if (event == "keydown")
                    {
                        callback();
                    }
                }
                if (_count == 60)
                {
                    if (event == "keyhold")
                    {
                        callback();
                    }
                }
                if (_count == 254)
                {
                    _count = 253;
                }
            }
            else
            {
                if (_count > 0)
                {
                    if (event == "keyup")
                    {
                        callback();
                    }
                    if (_count < 40)
                    {
                        if (event == "click")
                        {
                            callback();
                        }
                    }
                    _enable = false;
                    _count = 0;
                    _rebote = 0;
                }
            }
        }
    }
}