#include "Arduino.h"
#include "AsAnalogSensor.h"

AsAnalogSensor::AsAnalogSensor(byte pin, int interval, float res)
{
    _pin = pin;
    _interval = interval;
    _res = res;
    _timer = millis();
}

void AsAnalogSensor::addEventListener(String event, float th, varAfunction callback)
{
    if (millis() - _timer > _interval)
    {
        _timer = millis();
        _value = analogRead(_pin) * _res;
        _delta = _value - _oldValue;
        _delta = abs(_delta);
        if (event == "change")
        {
            if (_delta > th)
            {
                _oldValue = _value;
                callback(_value);
            }
        }
       
    }
}