
#ifndef AsAnalogSensor_h
#define AsAnalogSensor_h
#include "Arduino.h"

extern "C"
{
    typedef void (*varAfunction)(float);
}

class AsAnalogSensor
{
public:
    AsAnalogSensor(byte pin, int interval, float res);
    void addEventListener(String event, float th, varAfunction callback);

private:
    byte _pin;
    int _interval;
    float _res;
    unsigned long _timer;
    float _value;
    float _delta;
    float _oldValue;
};

#endif