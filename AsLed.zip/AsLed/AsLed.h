#ifndef AsLed_h
#define AsLed_h
#include "Arduino.h"

#define ACTIVE_HIGH true
#define ACTIVE_LOW false

class AsLed
{
public:
    AsLed(byte pin, boolean mode); // constructor genera el objeto
    void on();
    void off();
    void set(boolean status);
    void toggle();
    void start();
    void stop();
    void brightness(byte brillo);
    void blink(int duracion); // metodo
    void pulse(byte rep, int duracion);

private:
    byte _pin;
    unsigned long _timer;
    byte _count = 0;
    boolean _enable = false;
    boolean _mode;
};

#endif