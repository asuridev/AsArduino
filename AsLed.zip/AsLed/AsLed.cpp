#include "AsLed.h"
#include "Arduino.h"

AsLed::AsLed(byte pin, boolean mode)
{
    _pin = pin;
    _mode = mode;
    pinMode(_pin, OUTPUT);
}

void AsLed::on()
{
    if (_mode)
    {
        digitalWrite(_pin, HIGH);
    }
    else
    {
        digitalWrite(_pin, LOW);
    }
}

void AsLed::off()
{
    if (_mode)
    {
        digitalWrite(_pin, LOW);
    }
    else
    {
        digitalWrite(_pin, HIGH);
    }
}

void AsLed::set(boolean status)
{
    if (_mode)
    {
        digitalWrite(_pin, status);
    }
    else
    {
        digitalWrite(_pin, !status);
    }
}


void AsLed::toggle()
{
    digitalWrite(_pin, !digitalRead(_pin));
}

void AsLed::blink(int duracion)
{
    if (_enable)
    {
        if (millis() > _timer + duracion || millis() < _timer)
        {
            digitalWrite(_pin, !digitalRead(_pin));
            _timer = millis();
        }
    }
}

void AsLed::pulse(byte rep, int duracion)
{
    if (_enable)
    {
        if (millis() > _timer + duracion || millis() < _timer)
        {
            digitalWrite(_pin, !digitalRead(_pin));
            _timer = millis();
            _count++;

            if (_count >= rep * 2)
            {
                _enable = false;
            }
        }
    }
}

void AsLed::brightness(byte brillo)
{
    constrain(brillo, 0, 100);
    brillo = map(brillo, 0, 100, 0, 255);
    analogWrite(_pin, brillo);
}

void AsLed::start()
{
    _enable = true;
    _count = 0;
    _timer = millis();
}

void AsLed::stop()
{
    _enable = false;
}
